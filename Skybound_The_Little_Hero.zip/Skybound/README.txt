SKYBOUND — THE LITTLE HERO
==========================

A colorful original side-scrolling platform adventure inspired by classic platform games.

RUN LOCALLY
1. Extract the ZIP.
2. Open the Skybound folder.
3. Double-click index.html in a modern browser.

PUBLISH ON GITHUB PAGES
1. Upload index.html and README.txt directly to the root of a public GitHub repository.
2. Open Settings > Pages.
3. Choose Deploy from a branch, branch main, folder /(root), then Save.
4. Your site will be at https://YOUR-USERNAME.github.io/REPOSITORY-NAME/

CONTROLS
- Move: A/D or Left/Right arrows
- Jump: Space, W, or Up arrow
- Touch controls appear on smaller screens.

OBJECTIVES
- Collect golden coins.
- Jump on grumpy critters to defeat them.
- Use spring pads to reach higher platforms.
- Reach the star gate and explore both worlds.

No external libraries or assets required.
